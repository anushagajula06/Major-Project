from flask import Flask, request, jsonify, send_file, render_template
import os
import logging
from gtts import gTTS

# Initialize Flask app
app = Flask(__name__)

# Set up logging for debugging
logging.basicConfig(level=logging.DEBUG)

# Ensure the static folder exists if not
if not os.path.exists('static'):
    os.makedirs('static')

# Placeholder audio generation function using gTTS (Google Text-to-Speech)
def generate_audio(text, audio_path):
    tts = gTTS(text)
    tts.save(audio_path)

# Function to add CORS headers to the response
def add_cors_headers(response):
    response.headers['Access-Control-Allow-Origin'] = '*'  # Allows all domains
    response.headers['Access-Control-Allow-Methods'] = 'GET, POST, PUT, DELETE, OPTIONS'
    response.headers['Access-Control-Allow-Headers'] = 'Content-Type'
    return response

# Serve the HTML file for the frontend
@app.route('/')
def home():
    return render_template('index.html')  # Ensure `index.html` is in the `templates` folder

# Endpoint to generate audio based on the text
@app.route('/generate-audio', methods=['POST'])
def generate_audio_media():
    logging.debug("Received request to generate audio")
    data = request.get_json()
    text = data.get('text', '')

    # Ensure text is provided
    if not text:
        logging.error("Text is missing.")
        return jsonify({"error": "Text is required"}), 400

    try:
        logging.debug(f"Generating audio for text: {text}")
        audio_path = os.path.join('static', "output.wav")  # Save audio in the static folder
        generate_audio(text, audio_path)  # Generate audio

        # Create a response and add CORS headers
        response = jsonify({
            "audio_path": f"/static/output.wav"
        })
        return add_cors_headers(response)  # Add CORS headers manually
    except Exception as e:
        logging.error(f"Error generating audio: {str(e)}")
        return jsonify({"error": f"Error: {str(e)}"}), 500

# Endpoint to download the generated audio file
@app.route('/download-audio', methods=['GET'])
def download_audio():
    path = request.args.get('path', '')
    logging.debug(f"Request to download audio from path: {path}")

    # Check if the audio file exists
    if not os.path.exists(path):
        logging.error(f"Audio file not found at path: {path}")
        return jsonify({"error": "Audio file not found"}), 404

    # Return the audio file for download
    response = send_file(path, as_attachment=True)
    return add_cors_headers(response)  # Add CORS headers manually

if __name__ == '__main__':
    logging.debug("Starting Flask app on port 5002")
    app.run(debug=True, port=5004)

